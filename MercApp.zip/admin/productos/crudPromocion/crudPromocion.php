<?php

class crudPromocion
{
    public function agregarPromocion($datos)
    {
        $obj      = new conectar();
        $conexion = $obj->conexion();

        $sql = "INSERT INTO tbpromocion (fechaInicio, fechaFin, foto) VALUES ('$datos[0]', '$datos[1]', '$datos[2]')";

       return mysqli_query($conexion, $sql) or die ("error en el insercion promocion");

    }

    public function obtenPromocion($idPromocion)
    {
        $obj      = new conectar();
        $conexion = $obj->conexion();

        $mov = "SELECT idPromocion, fechaInicio, fechaFin FROM tbpromocion WHERE idPromocion=$idPromocion";

       
        $result = mysqli_query($conexion, $mov);
        $ver    = mysqli_fetch_row($result);

        $datos = array(
            'idPromocion'                    => $ver[0],
            'fechaInicio'                    => $ver[1],
            'fechaFin'                       => $ver[2]
            
        );
        return $datos;
    }

    public function actualizarPromocion($datos)
    {
        $obj      = new conectar();
        $conexion = $obj->conexion();
        if($datos[2]==0){
            $mov = "UPDATE tbpromocion SET fechaInicio='$datos[0]', fechaFin='$datos[1]' WHERE idPromocion=$datos[0]";
        }else {
            $mov = "UPDATE tbpromocion SET fechaInicio='$datos[0]', fechaFin='$datos[1]', foto='$datos[2]' WHERE idPromocion=$datos[0]";
        }
        

        return mysqli_query($conexion, $mov) or die ("error al actualizar tabla promocion");

    }
}
