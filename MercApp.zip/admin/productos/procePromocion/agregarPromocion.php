<?php
require_once "../clases/conexion.php";
require_once "../crudPromocion/crudPromocion.php";
$obj = new crudPromocion();
$foto = $_FILES['foto'];
if ($foto["type"] == "image/jpg" OR $foto["type"] == "image/jpeg" OR $foto["type"] == "image/png"){
    $ruta = "../imagenes/". $foto["name"];
    if (move_uploaded_file($foto["tmp_name"],  $ruta)) {
      
   $fotoNom= $foto["name"];
$datos = array(
    $_POST['fechaInicio'],
    $_POST['fechaFin'],
    $foto["name"]
	);

echo $obj ->agregarPromocion($datos);
    }
}