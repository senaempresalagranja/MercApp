
<?php 
require_once "../conn.php";
include("header.php");
include("script.php");

if (isset($_REQUEST['idPromocion'])) {
    ?>
    
    <?php 
    
      $query= mysqli_query($conn,"SELECT fechaInicio, foto FROM  tbpromocion WHERE idPromocion=".$_REQUEST['idPromocion']."  ORDER BY fechaInicio DESC LIMIT 1");
      $row= mysqli_fetch_row($query);
      ?>
      <img  src="../admin/productos/imagenes/<?php if (empty($row[1])){echo "upload/noimage.jpg";}else{echo $row[1];} ?>" class="img-responsive" alt="Responsive image">
  
<?php

}
else{
     
}
?>
