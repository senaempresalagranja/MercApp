
	<div class="well"  id="cart_box"  style="display:none;  top:55px; left:350px; max-width:850px; z-index:2;">
 	<div id="cart_area" style="max-height:300px;  overflow-y:auto; overflow-x:hidden;"></div>
		<div>
			<button type="button" class="btn btn-warning btn-sm" id="close_cart"><i class="fa fa-times fa-fw"></i> Cerrar</button> <a href="checkout.php" class="btn btn-primary btn-sm"><i class="fa fa-money fa-fw"></i> Confirmar Pedido</a>
		</div>
	</div>
	<div id="search_area" class="panel panel-default" style="display:none; position:fixed; top:55px; left:40%; height:40px; width:447px; z-index:3;">
	</div>