<?php
	include('session.php');
	
	$nombrecliente=$_POST['nombrecliente'];
	$dircliente=$_POST['dircliente'];
	$contactocliente=$_POST['contactocliente'];
	$nombreuser=$_POST['nombreuser'];
	$password=md5($_POST['password']);
	
	mysqli_query($conn,"insert into user (username, password, access) values ('$nombreuser', '$password', '2')");
	$iduser=mysqli_insert_id($conn);
	
	mysqli_query($conn,"insert into customer (idusuario, nombre_cliente, direccion, contact) values ('$iduser', '$nombrecliente', '$dircliente', '$contactocliente')");
	
	?>
		<script>
			window.alert('Cliente Agregado Correctamente!');
			window.history.back();
		</script>
	<?php
?>