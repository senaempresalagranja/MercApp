<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!--<meta http-equiv="x-ua-compatible" content="ie=edge">-->

        <title>MERCAPP</title>

        <!-- Font Awesome -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,800,600,300,300italic,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- Material Design Bootstrap -->
        <link href="css1/materialize.css" rel="stylesheet">

        <!-- Magnific-popup css -->
        <link href="css1/magnific-popup.css" rel="stylesheet">

        <!-- Bootstrap core CSS -->
        <link href="css1/bootstrap.min.css" rel="stylesheet">

        <!-- Material Design Bootstrap -->
        <!--<link href="css/progressbar.css" rel="stylesheet">-->

        <!-- Material Design Bootstrap -->
        <link href="css1/mdb.min.css" rel="stylesheet">
        
        


        <!-- nuestros estilos propios (optional) -->
        <link href="css1/style.css" rel="stylesheet">
        <link href="css1/responsive.css" rel="stylesheet">
        
        <style>
            #pie{
                background-color: black;
            }
        
        </style>

    </head>

    <body data-spy="scroll" >
        <!-- comienzo de nuestro proyecto-->
        <!--Navbar-->

        <div class='preloader'><div class='loaded' >&nbsp;</div></div> -->

        <nav class="navbar navbar-fixed-top navbar-light bg-faded" style="background-color: orange; width: 100%; height: 90px;">
            <!--boton de el menu colapsado es decir cuando el nav es en formato mobile-->
             <a href="#" data-activates="#mobile-menu" class="button-collapse right"><i class="fa fa-bars black-text"></i></a>

            <div class="container">
               
                <!--contenido para pantallas grandes y pequeñas-->
                <div class="navbar-desktop">
                    <!--Navbar marca-->
                    <a class="navbar-brand" href="#home"><img src="user/logomercapp.png" alt=""/></a>
                    <!--enlaces-->
                    <ul class="nav navbar-nav pull-right hidden-md-down">
                        <li class="nav-item">
                            <a class="nav-link" href="#home"><span class="fa fa-home"> Inicio<span class="sr-only">(current)</span></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#about"> <span class="fa fa-users"> Quienes Somos</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#service"><span class="fa fa-cog"> Servicios</span></a>
                        </li>
                     <!--   <li class="nav-item">
                            <a class="nav-link" href="#team">Team</a>
                        </li> -->
                        <!-- <li class="nav-item">
                            <a class="nav-link" href="catalogo.html"><span class="fa fa-book"> Catalogo</span></a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="#contacto"><span class="fa fa-phone"> Contactenos</span></a>
                        </li>
                         <li class="nav-item">
                             <a class="nav-link" href="ingreso.php"><span class="fa fa-sign-out">Ingresar</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" target="_blank" href="#!"><i class="fa fa-search fa-lg"></i></a>
                        </li>
                    </ul>
                    
                </div>

                <!-- Contenido para el nav en pantallas pequeñas-->
                <div class="navbar-mobile">

                    <ul class="side-nav" id="mobile-menu">
                        <li class="nav-item">
                            <a class="nav-link" href="#home"><span class="fa fa-home"> Inicio<span class="sr-only">(current)</span></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#about"><span class="fa fa-users"> Quienes somos</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#service"><span class="fa fa-cog"> Servicios</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#portfolio"><span class="fa fa-book"> Catalogo</span></a>
                        </li>
                    <!--    <li class="nav-item">
                            <a class="nav-link" href="#newsletter">Support</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="#!"><span class="fa fa-phone"> Contactenos</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><span class="fa fa-sign-out">Ingresar</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#!"><i class="fa fa-search fa-lg"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--/.Navbar-->


       
            
       



      

 
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="main_about_area">
                            <div class="head_title center m-y-3 wow fadeInUp">
                                
                            </div>

                            <div class="main_about_content">
                                <div class="row">
                                    <div class="col-md-6">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr/>
            <br/>
            <br/>
            <br/>
            <hr/>
        </section>
        <section id="home" class="home">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="main_about_area">
                              <div class="single_team white-text m-t-2 wow zoomIn">
                                            
                    <div id="home" class="slider single_team" style="height: 320px; touch-action: pan-y;-webkit-user-drag:none;margin-bottom: -340px; " >
            <ul class="slides" style="height: 560px;">
                <li>
                    <img src="img/zorrito1.jpg"> 
                    <div class="caption center-align">
                        <div class="single_home">
                          
                        </div>
                    </div>
                </li>
             
                <li>
                    <img src="img/2.jpg"> 
                    <div class="caption center-align">
                        <div class="single_home">
                       
                        </div>
                    </div>
                </li>
                <li>
                    <img src="img/1.jpg"> 
                    <div class="caption center-align">
                        <div class="single_home">
                          
                        </div>
                    </div>
                </li>
            </ul>
        </div>
          
                
                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
        </section>

        <section id="about" class="about">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="main_about_area">

                         

                            <div class="head_title center m-y-3 wow fadeInUp">
                                <h2 style="text-align: center;font-family:Georgia,Arial,Sans-serif;font-size: 80px;color:orange;margin-bottom: 80px;" >mercapp</h2>
                                <h3>QUIENES SOMOS</h3>
                                <p>Somos aprendices tecnologos de la fomacion <strong>Analisis y Desarollo de Sistemas de informacion</strong> puedes contactarnos</p>
                            </div>

                            <div class="main_about_content">
                                <div class="row">
                                    <div class="col-md-6">

                                        <div class="main_accordion wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">

                                            <div class="single_accordion">
                                                <button class="accordion">JUAN DANIEL VERA</button>
                                                <div class="panel">
                                                    <p> soy uno de los desarrolladores de Mercapp </p>
                                                </div>
                                            </div>

                                            <div class="single_accordion">
                                                <button class="accordion">VERONICA RODRIGUEZ</button>
                                                <div class="panel">
                                                    <p>soy una de las desarrolladores de Mercapp</p>
                                                </div>
                                            </div>

                                          <!--  <div class="single_accordion">
                                                <button class="accordion active">Lorem ipsum dolor sit amet</button>
                                                <div class="panel show">
                                                    <p>Consectetur adipiscing elit. Aliquam sagittis nulla non elit dignissim suscipit. Duis lorem nulla, 
                                                        eleifend Ut urna dui, interdum non blandit sed, hendrerit ultricies mi. 
                                                        Aliquam at scelerisque ligula. Curabitur id laoreet velit.</p>
                                                </div>
                                            </div> -->

                                            <div class="single_accordion">
                                                <button class="accordion">CARLOS MARIO DIAZ</button>
                                                <div class="panel">
                                                    <p> soy uno de los desarrolladores de Mercapp</p>
                                                </div>
                                            </div>

                                            <div class="single_accordion">
                                                <button class="accordion">MIGUEL FRANCISCO RUBIANO</button>
                                                <div class="panel">
                                                    <p>soy el lider y uno de los desarrolladores de Mercapp </p>
                                                </div>
                                            </div>

                                            <div class="single_accordion">
                                                <button class="accordion">LUIS FELIPE PALMA</button>
                                                <div class="panel">
                                                    <p>soy uno de los desarollades de Mercapp</p>
                                                </div>
                                            </div>
                                            
                                            <div class="single_accordion">
                                                <button class="accordion">ANDREA CAROLINA HERNANDEZ PRADA</button>
                                                <div class="panel">
                                                    <p>soy una de las desarollades de Mercapp</p>
                                                </div>
                                            </div>

                                        <!--    <div class="single_accordion">
                                                <button class="accordion">Lorem ipsum dolor sit amet</button>
                                                <div class="panel">
                                                    <p>Consectetur adipiscing elit. Aliquam sagittis nulla non elit dignissim suscipit. Duis lorem nulla, 
                                                        eleifend Ut urna dui, interdum non blandit sed, hendrerit ultricies mi. 
                                                        Aliquam at scelerisque ligula. Curabitur id laoreet velit.</p>
                                                </div>
                                            </div>-->
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="single_about about_progress">
                                            <div class="skill wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
                                                <!-- progress start -->
                                                <div class="progress">
                                                  <span class="fa fa-envelope">  <div class="lead">vqjuan@misena.edu.co</div></span>
                                                    <div class="progress-bar wow fadeInLeft" data-progress="95%" style="width: 95%;" data-wow-duration="1.5s" data-wow-delay="1.2s"></div>
                                                </div>
                                                <!-- progress end -->
                                                <!-- progress start -->
                                                <div class="progress">
                                                    <div class="lead">vrodriguez612@misena.edu.co</div>
                                                    <div class="progress-bar wow fadeInLeft" data-progress="90%" style="width: 90%;" data-wow-duration="1.5s" data-wow-delay="1.2s"></div>
                                                </div>
                                                <!-- progress end -->
                                                <!-- progress start -->
                                                <div class="progress">
                                                    <div class="lead">lllo@misena.edu.co</div>
                                                    <div class="progress-bar wow fadeInLeft" data-progress="85%" style="width: 85%;" data-wow-duration="1.5s" data-wow-delay="1.2s"></div>
                                                </div>
                                                <!-- progress end -->
                                                <!-- progress start -->
                                                <div class="progress">
                                                    <div class="lead">mfrubiano6@misena.edu.co</div>
                                                    <div class="progress-bar wow fadeInLeft" data-progress="80%" style="width: 80%;" data-wow-duration="1.5s" data-wow-delay="1.2s"></div>
                                                </div>
                                                <!-- progress end -->
                                                <!-- progress start -->
                                                <div class="progress">
                                                    <div class="lead">lfpalma2@misena.edu.</div>
                                                    <div class="progress-bar wow fadeInLeft" data-progress="70%" style="width: 70%;" data-wow-duration="1.5s" data-wow-delay="1.2s"></div>
                                                </div>
                                                 <div class="progress">
                                                    <div class="lead">achernandez519@misena.edu.co</div>
                                                    <div class="progress-bar wow fadeInLeft" data-progress="60%" style="width: 60%;" data-wow-duration="1.5s" data-wow-delay="1.2s"></div>
                                                </div>
                                                <!-- FIN DE QUIENES SOMOS -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr/>
            <br/>
            <br/>
            <br/>
            <hr/>
        </section><!-- End of About Section-->






        <section id="service" class="service">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="main_service_area">
                            <div class="head_title center m-y-3 wow fadeInUp">
                                <h2></h2>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="jumbotron single_service  wow fadeInLeft">
                                        <div class="service_icon center">
                                            <i class="fa fa-cog m-b-3"></i>
                                        </div>
                                        <div class="s_service_text text-sm-center text-xs-center">
                                            <h4>OBJETIVO DEL SISTEMA</h4>
                                            <p>Diseñar e implementar un sistema operativo hibbrido nativo web con el fin de ayudar a la gestion
                                                de el inventario de los productos que se comercializan en mercasena
                                                </p>
                                        </div>

                                        <div class="service_btn center">
                                            <a href="#!" class="btn btn-danger waves-effect waves-red">GRACIAS</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="jumbotron single_service wow fadeInUp">
                                        <div class="service_icon center">
                                            <i class="fa fa-pied-piper m-b-3"></i>
                                        </div>
                                        <div class="s_service_text text-sm-center text-xs-center">
                                            <h4>FUNCIONALIDAD</h4>
                                            <p>Mercapp va a ser una herramienta virtual para que tanto usuarios clientes y administrador tenga un pleno conocimiento en los productos que se comercializan en mercasena</p>
                                        </div>

                                        <div class="service_btn center">
                                            <a href="#!" class="btn btn-danger waves-effect waves-red">gracias</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="jumbotron single_service wow fadeInRight">
                                        <div class="service_icon center">
                                            <i class="fa fa-sign-out m-b-3"></i>
                                        </div>
                                        <div class="s_service_text text-sm-center  text-xs-center">
                                            <h4>ALCANCE</h4>
                                            <p>Se pretende llevar a Mercapp a un contexto mayor es decir queremos 
                                                en un futuro poder comercializar este proyecto para que asi nos puedan conocer en el mercado
                                             </p> 
                                        </div>

                                        <div class="service_btn center">
                                            <a href="#!" class="btn btn-danger waves-effect waves-red">GRACIAS</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr />
        </section> 



   



    


        <section id="team" class="team">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="main_team_area m-y-3">
                            <div class="head_title center  wow fadeInUp">
                                <h2>PRODUCTOS</h2>
                               
                            </div>

                            <div class="main_team_content center">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="single_team white-text m-t-2 wow zoomIn">
                                            <img src="img/zorro1.jpg" alt="team" />
                                            <div class="single_team_overlay">
                                                <h4>MaNJAR DE CAFE</h4>
                                                <p>elaboracion artesanal</p>
                                                <div class="team_socail">
                                                    <a href="#!"><i class="fa fa-facebook"></i></a>
                                                    <a href="#!"><i class="fa fa-twitter"></i></a>
                                                    <a href="#!"><i class="fa fa-pinterest-p"></i></a>
                                                    <a href="#!"><i class="fa fa-dribbble"></i></a>
                                                    <a href="#!"><i class="fa fa-behance"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="single_team white-text m-t-2 wow zoomIn">
                                            <img src="img/zorro2.jpg" alt="team" />
                                            <div class="single_team_overlay">
                                                <h4>Arroz con leche</h4>
                                                <p>Elaboracion con ingredientes 100% naturales</p>
                                                <div class="team_socail">
                                                    <a href="#!"><i class="fa fa-facebook"></i></a>
                                                    <a href="#!"><i class="fa fa-twitter"></i></a>
                                                    <a href="#!"><i class="fa fa-pinterest-p"></i></a>
                                                    <a href="#!"><i class="fa fa-dribbble"></i></a>
                                                    <a href="#!"><i class="fa fa-behance"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="single_team white-text m-t-2 wow zoomIn">
                                            <img src="img/zorro3.jpg" alt="team" />
                                            <div class="single_team_overlay">
                                                <h4>Zumo de limon</h4>
                                                <p>Elaborado con el estracto de zumo del limon</p>
                                                <div class="team_socail">
                                                    <a href="#!"><i class="fa fa-facebook"></i></a>
                                                    <a href="#!"><i class="fa fa-twitter"></i></a>
                                                    <a href="#!"><i class="fa fa-pinterest-p"></i></a>
                                                    <a href="#!"><i class="fa fa-dribbble"></i></a>
                                                    <a href="#!"><i class="fa fa-behance"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="single_team white-text m-t-2 wow zoomIn">
                                            <img src="img/zorro4.jpg" alt="team" />
                                            <div class="single_team_overlay">
                                                <h4>Nectar de mora</h4>
                                                <p>Elaborado con el estracto del nectar de la mora</p>
                                                <div class="team_socail">
                                                    <a href="#!"><i class="fa fa-facebook"></i></a>
                                                    <a href="#!"><i class="fa fa-twitter"></i></a>
                                                    <a href="#!"><i class="fa fa-pinterest-p"></i></a>
                                                    <a href="#!"><i class="fa fa-dribbble"></i></a>
                                                    <a href="#!"><i class="fa fa-behance"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- End of col-sm-3 -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr />
        </section><!-- End of Team section -->

<!-- FIN DE  -->



      

        <section id="newsletter" class="newsletter" style="width: 100%;height: 80%;background-color: #000;">
            <div class="container">
                <div class="row">
                    <div class="main_newsletter white-text p-y-2 m-t-3">
                       <p style="text-align: center;font-family: Castellar;color: #fff;font-size:40px; ">MERCAPP</p>
                       <div class="team_socail" style="margin-left: 1030px;font-size: 20px;">
                                                    <a href="#!"><i class="fa fa-facebook"></i></a>
                                                    <a href="#!"><i class="fa fa-twitter"></i></a>
                                                    <a href="#!"><i class="fa fa-pinterest-p"></i></a>
                                                    <a href="#!"><i class="fa fa-dribbble"></i></a>
                                                    <a href="#!"><i class="fa fa-behance"></i></a>
                                                </div>
                                                
                                           
                        
                       <!-- <div class="col-md-6 col-sm-12 col-xs-12">
                            <div class="single_newsletter text-md-right text-sm-center wow zoomIn">
                                <div class="md-form input-group">
                                    <input type="text" class="form-control" placeholder="Contactanos..." style="background-color: white;color: white;">
                                    <span class="input-group-btn">
                                        <button class="btn waves-effect waves-blue" type="button"><i class="fa fa-send"></i></button>
                                    </span>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </section><!-- End of Newsletter section -->
        
        
        
     



       
        <!-- /Start your project here-->


        <!-- SCRIPTS -->

        <!-- JQuery -->
        <script type="text/javascript" src="js1/jquery-2.2.3.min.js"></script>

        <!-- Bootstrap tooltips -->
        <script type="text/javascript" src="js1/tether.min.js"></script>


        <!-- Bootstrap core JavaScript -->
        <script type="text/javascript" src="js1/bootstrap.min.js"></script>

        <!-- MDB core JavaScript -->
        <script type="text/javascript" src="js1/mdb.min.js"></script>

        <!-- Wow js -->
        <script type="text/javascript" src="js1/wow.min.js"></script>

        <!-- Mixitup js -->
        <script type="text/javascript" src="js1/jquery.mixitup.min.js"></script>

        <!-- Magnific-popup js -->
        <script type="text/javascript" src="js1/jquery.magnific-popup.js"></script>

        <!-- accordion js -->
        <script type="text/javascript" src="js1/accordion.js"></script>

        <!-- MDB core JavaScript -->
        <script type="text/javascript" src="js/materialize.js"></script>

        <script>
            $(".button-collapse").sideNav();
        </script>

        <!-- wow js active -->
        <script type="text/javascript">
            new WOW().init();
        </script>

        <script type="text/javascript" src="js1/plugins.js"></script>
        <script type="text/javascript" src="js1/main.js"></script>


    </body>

</html>